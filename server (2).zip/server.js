const express = require("express");
const sequelize = require("./config/database");

const User = require("./app/models/User");
const Category = require("./app/models/Category");
const Book = require("./app/models/Book");
const Loan = require("./app/models/Loan");

const userRoutes = require("./app/routes/userRoutes");

const app = express();

app.use(express.json());

// Rotas
app.use("/users", userRoutes);

// Relacionamentos
Category.hasMany(Book, { foreignKey: "categoryId" });
Book.belongsTo(Category, { foreignKey: "categoryId" });

User.hasMany(Loan, { foreignKey: "userId" });
Loan.belongsTo(User, { foreignKey: "userId" });

Book.hasMany(Loan, { foreignKey: "bookId" });
Loan.belongsTo(Book, { foreignKey: "bookId" });

// Rota inicial
app.get("/", (req, res) => {
  res.send("API Biblioteca funcionando!");
});

// Conectar ao banco e iniciar servidor
sequelize
  .sync({ alter: true })
  .then(() => {
    console.log("✅ Banco sincronizado!");

    app.listen(3000, () => {
      console.log("🚀 Servidor rodando na porta 3000");
    });
  })
  .catch((err) => {
    console.error("❌ Erro:", err);
  });
